// JavaScript Function Practice

function hello(name)
{
   alert("Hello " + name);
}

function helloWorld()
{
   document.writeln("Hello world!");
}

function toPercent(decimal)
{
	var percent = decimal * 100;
	return percent;
}
